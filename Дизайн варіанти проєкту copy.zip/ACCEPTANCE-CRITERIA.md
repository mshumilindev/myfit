# My Fit — acceptance criteria

Testable ACs for the two design updates. Format: `AC-<area>-<n>`. Each is independently verifiable; frame ids in brackets point at the design.

Legend — **MUST** is a hard requirement, **MUST NOT** a prohibition. Timings are wall-clock on a mid-range phone over a normal connection.

---

## 1 · Gym search — providers

**AC-SEARCH-01 [G-01]** On opening “Add a gym”, the client MUST issue exactly one geolocation read (`enableHighAccuracy: true`, `timeout: 8000`) and MUST render nearby results before the user types anything.

**AC-SEARCH-02 [G-02, GW-01]** All four providers (local DB, OpenStreetMap, Google Places, Foursquare) MUST be queried **in parallel**, not sequentially. Total wall time to the first rendered result MUST NOT exceed the latency of the fastest responding provider + 150 ms.

**AC-SEARCH-03 [G-02]** Each provider MUST have a chip in the results header with three visual states: pending (spinner, graphite), answered (emerald check + integer count), failed (graphite, count `—`, tooltip/subline with the reason). A failed provider MUST NOT block or hide results from the others.

**AC-SEARCH-04 [G-02]** Results MUST stream: a provider's rows appear as soon as that provider answers. The list MUST NOT wait for the slowest provider, and rows MUST NOT reorder once rendered except to merge a duplicate (see AC-SEARCH-05).

**AC-SEARCH-05 [G-02, GW-01]** Two results MUST be merged into one row when either (a) both have coordinates within 60 m **and** normalised names have Levenshtein distance ≤ 2, or (b) they share an external id already linked in the local DB. The merged row MUST list every contributing source as a tag.

**AC-SEARCH-06** Typing MUST debounce at 350 ms. A new query MUST cancel all in-flight provider requests for the previous query (`AbortController`), and late responses from a cancelled query MUST be discarded.

**AC-SEARCH-07 [G-02]** Between 300 ms and the first result the list MUST show skeleton rows matching the real row geometry (64 × 64 thumb, two text lines). No spinner may appear in the list body — the provider chips carry that role.

**AC-SEARCH-08 [G-03]** When every provider returns zero results, the empty state MUST show each provider with `· 0` and MUST render the manual-add form pre-filled with (a) the exact string typed and (b) the current GPS fix with its accuracy in metres.

**AC-SEARCH-09 [GW-01]** On desktop, geolocation is IP-derived; the UI MUST state the accuracy (±2 km), MUST NOT offer “Pin here”, and MUST offer “add from your phone” instead.

**AC-SEARCH-10** Provider failures MUST be logged with provider name, HTTP status and duration, and MUST NOT surface as a toast or dialog — the chip is the only user-facing signal.

**AC-SEARCH-11** All provider results MUST be cached per (query, rounded 100 m location) for 24 h, so re-opening search offline still lists what was seen before.

---

## 2 · Gym imagery

**AC-IMG-01 [G-01, G-02]** Photo resolution MUST follow this order and stop at the first hit: venue-attached photo (Places / OSM `image` / Foursquare) → Google Images → house graphic.

**AC-IMG-02 [G-04, GW-02]** Google Images candidates MUST be filtered to ≥ 600 px on the **shorter** side and MUST be capped at 8 results. Desktop MUST display each candidate's pixel dimensions.

**AC-IMG-03 [G-04, GW-02]** The picker MUST offer the house graphic as an equal-weight choice — a button (phone) or the last tile in the grid (desktop) — never a text link, never smaller than the other options.

**AC-IMG-04 [G-05]** If no candidate meets the size filter, the app MUST show the failure state with the house graphic rendered **at real size**, plus two actions: “Take one now” (camera) and “Keep graphic”. It MUST NOT silently fall back without telling the user.

**AC-IMG-05** The chosen image MUST be fetched **once**, downscaled so the long edge ≤ 1600 px, re-encoded (WebP q80, JPEG fallback), and stored on the user's hub at `/media/gyms/<gymId>.<ext>`. The client MUST NOT hot-link the source URL at render time.

**AC-IMG-06** The gym record MUST persist `photoSource ∈ {places, osm, foursquare, google-images, manual, generic}` and `photoCachedAt` (ISO 8601). [G-06] Both MUST be visible on the gym detail screen with a “Replace” affordance.

**AC-IMG-07** The house graphic MUST be generated **locally** (CSS/canvas, no network) and MUST render correctly at every slot size from 64 px to 320 px. It MUST NOT be labelled “missing”, “no image”, or similar.

**AC-IMG-08** Photos MUST appear at exactly four slot sizes: 320 px pane header · hero (210/150/60 web, 148/126/52 phone) · 120 px card · 64 × 64 phone thumb / 72 × 56 web thumb. Any other size is a defect.

**AC-IMG-09 [G-06, G-07, GW-01]** Every photo used behind text MUST carry a scrim reaching `rgba(22,23,26,0.94)` at the text edge. Measured contrast of overlaid text MUST be ≥ 4.5:1 against the composited background for body text and ≥ 3:1 for ≥ 24 px text.

**AC-IMG-10** Image load MUST be progressive: skeleton at the slot's exact height → decoded image swapped in place. Layout shift (CLS contribution) MUST be 0.

**AC-IMG-11** A cached image that fails to load (deleted file, corrupt) MUST fall back to the house graphic within the same frame and MUST re-queue a background re-fetch, without an error toast.

**AC-IMG-12** Replacing a photo MUST delete the previous cached file after the new one is written, and MUST be undoable within the same session via the standard 5 s snackbar.

---

## 3 · Live-session hero

**AC-HERO-01 [G-08…G-12, GW-03…GW-06]** While `openWorkout != null`, the hero MUST be mounted above the router outlet on **every** screen — Today, Progress, Gyms, Apps, History, Templates, and every sheet's parent. There MUST be no route where an open session is invisible.

**AC-HERO-02** Heights MUST be exactly: phone 148 (own screen) / 126 (in session) / 52 (elsewhere or scrolled); web 210 / 150 / 60; menu-bar popover 110.

**AC-HERO-03** Expanded → collapsed MUST be a height transition of 180 ms `ease-out`, triggered at 64 px of scroll, with 16 px hysteresis to prevent flapping. The photograph MUST NOT cross-fade, re-request, or re-decode during the transition.

**AC-HERO-04** The hero background MUST be the current gym's cached photo; when the session has no gym attached it MUST be the house graphic. It MUST NOT be blank at any point, including first paint.

**AC-HERO-05** The brass 1 px hairline under the band MUST be present in every state except offline (where it is ruby). It is the invariant signal — no state may remove it.

**AC-HERO-06** The live dot MUST pulse on a 2.6 s cycle and MUST respect `prefers-reduced-motion: reduce` by rendering static at full opacity.

**AC-HERO-07** The timer MUST use `tabular-nums` and MUST NOT change layout width between `09:59` and `10:00`. It MUST tick from the persisted `startedAt`, so a reload or a backgrounded tab shows the correct elapsed time, never a restarted count.

**AC-HERO-08 [G-12]** Rest state: the band tints to `rgba(52,39,19,0.92)`, the timer slot shows the rest countdown, and a `Skip` control appears. Returning to logging MUST restore the session timer without a height change.

**AC-HERO-09 [G-12]** Offline while live: the dot and hairline turn ruby and the label reads `Live · offline · N queued`, where N is the real queue length. The photograph MUST remain visible — offline is not a degraded visual state.

**AC-HERO-10 [G-11]** When GPS matches no saved gym (outside every radius), the session MUST still start and run. The hero uses the house graphic, and a dismissible card below offers “Search nearby”, “Pin here”, “Not now”, plus the closest saved gym with its distance.

**AC-HERO-11** Attaching a gym mid-session MUST swap the hero image in place, retroactively assign the workout to that gym, and MUST NOT interrupt the timer or lose logged sets.

**AC-HERO-12 [G-08, GW-03]** While live, Today MUST NOT render a “Start session” button, and Today's headline MUST drop to 26 px (phone) / 28 px (web).

**AC-HERO-13 [GW-03, GW-05]** On web the hero spans the content pane only, never the rail. The rail MUST show a brass dot on the Today icon whenever a session is open, including in windows under 720 px.

**AC-HERO-14 [GW-05]** The collapsed web band MUST be sticky: scrolling the content pane MUST NOT move or remove it.

**AC-HERO-15** Tapping/clicking anywhere in the collapsed band MUST navigate to the session. The `Resume` button MUST have a hit area ≥ 44 × 44 px on phone.

**AC-HERO-16** Auto-close at `startedAt + 8 h` MUST turn the dot graphite, change the label to `Closed automatically`, and replace `Resume` with `Reopen`. The hero MUST disappear only after the session is finished or reopened-and-finished.

**AC-HERO-17** The hero MUST be the only component in the product rendering a full-bleed photograph. Any other full-bleed image is a defect.

---

## 4 · Regression guards (unchanged behaviour that must survive)

**AC-REG-01** Ghost-row logging: prefilled from the last session, Log commits and renumbers, remaining sets renumber on delete. [S-19, S-22]

**AC-REG-02** Reversible deletes (set, exercise, template) → 5 s undo snackbar, no dialog. Irreversible-after-sync deletes (workout, gym, sign-out with queue) → dialog naming what is lost and what survives, no undo. [S-21…S-26, S-31, S-48]

**AC-REG-03** Loading thresholds: nothing < 300 ms · skeleton 300 ms–2 s · labelled spinner > 2 s or unknown. One mechanism per surface. [S-10, S-34, S-50]

**AC-REG-04** Offline: writes land locally first, the queue replays in order, queued records carry neutral tags, and only a blocked queue gets a persistent card with the raw reason plus Retry / Discard. [S-14…S-16]

**AC-REG-05** Colour discipline: brass only for action / focus / live, emerald only for success / records / healthy sync, ruby only for destructive / failure / offline. Primary buttons stay outlined; the accent never floods a surface — the hero photo band is not an exception, since its colour comes from the photograph, not the accent.

**AC-REG-06** Every list surface ships with all four of empty, skeleton, filled and failed. A screen with only the filled state is incomplete.
