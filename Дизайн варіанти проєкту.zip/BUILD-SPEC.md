# My Fit — build spec

Design source of truth for implementation. Four files in this project:

| File | What it is |
| --- | --- |
| `My Fit - Graphite.dc.html` | Clickable prototype — phone + desktop, real interactions (tabs, session logging, rest timer, toasts, dialogs) |
| `My Fit - All States.dc.html` | Mobile state inventory, 50 frames, ids **S-01 … S-50** |
| `My Fit - All States (Web).dc.html` | Web / desktop state inventory, 13 frames, ids **W-01 … W-13** |
| `Current UI (recreation).dc.html` | Faithful recreation of today's UI, for before/after |

Superseded explorations kept for reference: `Variant A - Tabs`, `Variant B - Sheet`, `Variant C - Hub`.

## Concept

Multi-user product (accounts, sign-up open, server sync), offline-first client. Shell = auth + sync + services registry; Training is service #1. Copy voice: plain, factual, no exclamation marks, numbers over adjectives.

## Tokens

```
bg           #16171a      surface      #1f2125      hairline  #3b3f43
text         #e9eaec      muted        #90959a      dim       #71767b
accent       #d9a24f      accent tint  #342713      accent-300 #eed3a5
ok           #4cbe8c      ok tint      #16291f      ok text   #b7e8cf
danger       #e2564f      danger tint  #2c1614      danger text #f3c2bf
skeleton     #262a2d
```

Type: Inter 400/500. Display 30–40 / −0.025em · title 22 · body 15 · secondary 13 · meta 11–12 · label 10 uppercase 0.12em. All numbers `tabular-nums`.
Metrics: radius 8 / 14 · tap target ≥ 44 px · phone gutter 18–20 px · card padding 13–16 px · spacing 5.6 / 8.4 / 11.2 / 16.8 / 22.4.

## Colour rules

1. Brass = action, focus, live session. Outlined buttons only — accent never fills a surface.
2. Emerald = success, records, healthy sync.
3. Ruby = destructive, failure, offline.
4. Everything else graphite. Queued/auto-closed states use neutral tags, not ruby.

## Interaction rules

- **Set logging** is the ghost row: prefilled from last time, tap a number to nudge (phone) / type + Enter (desktop), Log commits and renumbers.
- **Reversible** (set deleted, exercise deleted, template deleted) → undo snackbar, 5 s, no dialog.
- **Irreversible after sync** (whole workout, gym, sign-out with queue) → dialog naming what is lost *and* what survives. No undo.
- **Deleting an exercise that holds sets** → dialog + undo. Empty exercise → straight delete + undo.
- **Loading**: < 300 ms nothing · 300 ms–2 s skeleton shaped like the real layout · > 2 s or unknown spinner with a label. One or the other per surface, never both.
- **Offline** is a state, not an error: local write first, queue replays in order, only a blocked queue gets a persistent card with the raw reason + Retry / Discard.
- **8-hour rule**: open session auto-closes at start + 8 h, marked brass (rule fired as designed), reopenable.

## Screen map

**Mobile (S-xx)** — Auth 01–06 · Shell & Today 07–16 (skeleton 10, empty 11, offline 14, syncing 15, failed 16) · Session 17–29 (add-exercise sheet 18, ghost row 19, PR + rest 20, set editor 21, set delete + undo 22, rename exercise 23, exercise menu 24, delete dialog 25, undo 26, auto-close 27, finish warning 28, summary 29) · History/Progress/Templates 30–40 · Gyms 41–48 · Notification kit 49 · Skeleton kit 50.

**Web (W-xx)** — Auth 01–02 · Today 03–05 · Session 06–09 (keyboard logging, inline edit + context menu, exercise editing surfaces, summary page) · History two-pane 10 · Progress 11 · Gyms 12 · Tray popover / 400 px window / shortcut sheet 13.

## Desktop specifics

Rail replaces the tab bar (account chip at its foot). Keyboard: ⌘N new session · ⌘K add exercise · ⏎ log · ⌥↑↓ weight ±2.5 · ⇧W warm-up · ⌫ delete selected · ⌘Z undo · ⌘⏎ finish · `?` shortcuts. Right-click menus everywhere a ⋮ exists, each item showing its shortcut. Hover = 4% text tint. Under 720 px the rail collapses to a hamburger and the layout matches the phone. Desktop geolocation is IP-based (±2 km) — adding a gym is delegated to the phone.

## New vs today's app

Added: templates / repeat session, previous-weight ghost values, progress charts (weekly volume, est. 1RM, records), rest timer, session summary with PR comparison, full empty/skeleton/error coverage, undo everywhere reversible.
